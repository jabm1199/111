#include <stdio.h>

int main()
{
	printf("hello world!\n");
}